<?php

namespace Database\Seeders;

use App\Models\Attendance;
use App\Models\Student;
use Illuminate\Database\Seeder;
use Carbon\Carbon;

class AttendanceSeeder extends Seeder
{
    public function run()
    {
        $students = Student::all();

        foreach ($students as $student) {
            $statusOptions = ['ontime', 'late', 'permit', 'sick'];

            for ($i = 0; $i < 1; $i++) {
                $date = Carbon::now()->subMonth()->startOfMonth()->addDays(rand(0, 29));

                Attendance::create([
                    'student_id' => $student->id,
                    'status' => $statusOptions[array_rand($statusOptions)],
                    'check_in_time' => $date->copy()->setTime(rand(6, 10), rand(0, 59)),
                    'check_out_time' => $date->copy()->setTime(rand(14, 18), rand(0, 59)),
                ]);
            }
        }
    }
}
