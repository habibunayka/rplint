<?php $__env->startSection('title', __('Payment Required')); ?>
<?php $__env->startSection('code', '402'); ?>
<?php $__env->startSection('message', __('Payment Required')); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project-Penting\RPLint\rplint-dashboard\vendor\laravel\framework\src\Illuminate\Foundation\Exceptions\views\402.blade.php ENDPATH**/ ?>