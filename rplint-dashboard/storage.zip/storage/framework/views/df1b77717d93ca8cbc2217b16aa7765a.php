<div
    <?php echo e($attributes->class(['fi-no-notification-body overflow-hidden break-words text-sm text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH E:\Project-Penting\RPLint\rplint-dashboard\vendor\filament\notifications\resources\views\components\body.blade.php ENDPATH**/ ?>