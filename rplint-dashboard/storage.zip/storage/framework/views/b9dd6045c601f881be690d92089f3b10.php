<time
    <?php echo e($attributes->class(['fi-no-notification-date text-sm text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e($slot); ?>

</time>
<?php /**PATH E:\Project-Penting\RPLint\rplint-dashboard\vendor\filament\notifications\resources\views\components\date.blade.php ENDPATH**/ ?>