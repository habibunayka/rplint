<div <?php echo e($attributes->class(['flex gap-x-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH E:\Project-Penting\RPLint\rplint-dashboard\vendor\filament\forms\resources\views\components\rich-editor\toolbar\group.blade.php ENDPATH**/ ?>