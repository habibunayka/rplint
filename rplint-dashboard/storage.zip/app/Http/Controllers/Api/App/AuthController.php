<?php

namespace App\Http\Controllers\Api\App;

use App\Models\Student;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController
{
    public function login(Request $request)
    {
        $request->validate([
            'nis' => 'required',
            'password' => 'required',
        ]);

        $user = User::whereHas('student', fn($q) => $q->where('nis', $request->nis))->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            return response()->json([
                'status' => 'failed',
                'message' => 'Nis atau Password anda salah!',
            ], 400);
        }

        $userData = Student::where('nis', $request->nis)->first();

        $token = $user->createToken('RPLintApp')->plainTextToken;

        return response()->json([
            'status' => 'success',
            'message' => 'You have been succesfully log in',
            'token' => $token,
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'nis' => $userData->nis,
                'class_name' => $userData->generationClass->class_name,
                'nisn' => $userData->nisn,
                'profile_photo' => $userData->profile_photo,
                'address' => $userData->address,
                'phone_number' => $userData->phone_number,
            ],
        ]);
    }


    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();
        return response()->json([
            'message' => 'You just logged out'
        ], 201);
    }
}
